## Tips from T.Chow
- MaxHeap/MinHeap: 
All you need to do is enter the array and the heap commands in main. 
This program provides outputs similar to project 2. This program will automatically build the heap and 
heapify the array you entered similar to project 2 aswell as provide the number of heapify calls when 
build heap and extract are run. This heap uses indexing at 1 as you can see when the heap is outputted.

## Run C++
```c++
g++ MaxHeap.cpp -o output.c
./output.c
```
