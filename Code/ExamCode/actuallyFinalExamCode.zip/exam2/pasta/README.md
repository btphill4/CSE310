## Tips from Pasta
For heaps, make sure to use Heaps.java as a main driver

## Run Java (VSCode)
```java
javac Heaps.java
java Heaps.java
```

## Install Java on Mac (For VSCode)
- https://devqa.io/brew-install-java/