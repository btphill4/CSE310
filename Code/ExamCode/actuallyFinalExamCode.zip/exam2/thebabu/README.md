## Tips from thebabu
- DOWNLOAD ALL FILES INCLUDING /src/ FOLDER IN ORDER TO WORK
- bfs-dfs-topo.html is the "driver file"
- Modify THEGRAPH variable to create a new graph
- DFS, BFS, TOPO options are at the bottom (uncomment)

## Run in Browser
- Copy bfs-dfs-topo.html path and paste as URL in any browser
- Or
- Click double click the file
