## Tips from T.Chow
For decision trees just use whichever algorithm they ask, enter an array that matches whatever leaf node they ask, and then follow the element wise comparisons the program outputs
Just gotta remember what the original positions of each element were when reading the element comparisons.

## Run C++
```c++
g++ MaxHeap.cpp -o output.c
./output.c
```