#ifndef HEAP_HPP
# define HEAP_HPP

class Heap
{
	public:
		/*Heap(void);
		Heap(** replace parameters **);
		Heap(Heap const &instance);
		Heap &operator=(Heap const &rhs);
		~Heap(void);*/

	private:

};

#endif