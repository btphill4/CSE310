/** 
 * Author: Brandon Phillips
 * Function: Header file for Util.cpp which uses the next command 
 * to parse input to the main
*/

#ifndef Util_hpp
#define Util_hpp
#include <stdlib.h>
 

int nextCommand(int *n,int *f);

int nextWord(char *word);

#endif