#ifndef util_h
#define util_h
#include <stdlib.h>
 

int nextCommand(int *n,int *f);


#endif