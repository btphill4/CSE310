~/run < input.txt > output.txt
cat HEAPoutput.txt >> output.txt
