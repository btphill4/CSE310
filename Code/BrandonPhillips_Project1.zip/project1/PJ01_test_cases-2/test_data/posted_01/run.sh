~/run < input.txt > output.txt
