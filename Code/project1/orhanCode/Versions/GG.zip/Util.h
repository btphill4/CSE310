#ifndef Util_hpp
#define Util_hpp
#include <stdlib.h>
 

int nextCommand(int *n,int *f);


#endif