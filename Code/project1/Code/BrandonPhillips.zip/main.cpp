//=============================================================================
//The following is a partial program that calls the above program.
//=============================================================================
#include <stdio.h>
#include <stdlib.h>
#include "util.h"
//testing
/*int main()
{
    // variables for the parser...
    char c;
    int i, v;
    int n, f;
    while(1){
        c = nextCommand(&n, &f);
        switch (c) {
        case ’s’:
        case ’S’: printf("COMMAND: %c\n", c); exit(0);
        case ’c’:
        case ’C’: printf("COMMAND: %c %d\n", c, n);
            heap = heapInit(n);
            break;
        case ’r’:
        case ’R’: printf("COMMAND: %c\n", c);
             ifile = fopen("HEAPinput.txt", "r");
            if (!ifile){
            }
            fscanf(ifile, "%d", &n);
            ...
            default: break;
        }
    }
exit(0);
}*/
//=============================================================================